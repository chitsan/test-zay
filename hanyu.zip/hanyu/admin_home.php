


<?php require('sidemenu.php');?>
         <div class="container">
<div class="content">
<header class="w3-display-container w3-content w3-wide" style="max-width:1500px;" id="home">
  <img class="w3-image" src="./img/adminflo.jpg" alt="" width="1500" height="800">
  <div class="w3-display-middle w3-margin-top w3-center">
   
  </div>
</header>
</div>



        
        
