<?php require('sidemenu.php');

  ?>
<?php

 if(isset($_GET["did"])){
		$id=$_GET["did"];
		$statement=$connection->prepare("Delete From admin where admin_id=?");
		$statement->bind_param("i",$id);
		$statement->execute();
		if($statement->error){
		$statement->close();
			echo"<script>alert('Something Wrong!');</script>";
		}
		else{
		$statement->close();
		
		echo"<script>alert('Admin information  is deleted successfully !');location.assign('adminlist.php');</script>";
		}
	}
 ?>
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
            <div class="row">
            <div class="container">
                <div class="table-responsive" style=" overflow:auto;">
                    <table class="table" style="border:2px solid black; width:99%;">
                        <thead style="background-color: skyblue; color:black;">
                            <tr style="font-size: 1.2em;">
                                <th>Name</th>                   
                                <th>Email</th>
                                <th>Password</th>   
                                                 
                                <th class="text-center" colspan="2">Action</th>
                            </tr>
                        </thead>
                        <tbody>
			<?php
				$result=$connection->query("Select * from admin");
				while($row=$result->fetch_assoc()){
				$admin_id = $row["admin_id"];
	
			?>
			<tr>
				<td><?php echo $row["admin_name"];?></td>
				<td><?php echo $row["email"];?></td>
				<td><?php echo $row["admin_password"];?></td>
			
				<td><input type="button" value="Update" class="btn btn-success" onclick="location.assign('updateadmin.php?uid=<?php echo $admin_id;?>')"/></td>
				<td><input type="button" value="Delete" class="btn btn-danger"  onclick="location.assign('adminlist.php?did=<?php echo $admin_id;?>')"/></td>
			</tr>
			<?php } $result->free(); ?>
                        </tbody>
                    </table>
                </div>
                </div>
        </div>
  </div>


        
        
