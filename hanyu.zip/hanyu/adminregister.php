<?php require('sidemenu.php');
 ?>
	
<?php 
if (isset($_POST["registeradmin"])) 
	{
                $admin_name=$_POST["admin_name"];
		$admin_email=$_POST["admin_email"];
		$admin_password=$_POST["admin_password"];
		$statement=$connection->prepare("Select * From admin Where email=?");
		$statement->bind_param("s",$admin_email);
		$statement->execute();
		if($statement->fetch()){
			echo"<script>alert('Email already exists.Try other email!');</script>";
		}
		else{	
		$statement = $connection ->prepare("Insert Into admin(admin_name,admin_password,email) Values(?,?,?)");
		
			$statement ->bind_param("sss",$admin_name,$admin_email,$admin_password);
			$statement ->execute();
			if($statement->error)
			{
				$err=$statement ->error;
				echo"<script>alert('$err');</script>";
			}
			else{
				echo "<script>alert('Successfully Register!');location.assign('adminregister.php');</script>";
			}
			$statement ->close();
		}
	}?>			
	  <!-- Content Wrapper. Contains page content -->
	 
            <div class="content-wrapper">		
			 <section class="content">
                    <div class="row">
                        <!-- left column -->
                             <div class="col-md-9">
                            <!-- Horizontal Form -->
                            <div class="box box-info">
                                <div class="box-header with-border">
                                    <h3 class="text-centre">Admin Registration Form</h3>
                                </div>
                                <!-- /.box-header -->
                                <!-- form start -->
                                <form class="form-horizontal" method='post' >
                                    <div class="box-body">
									
                                        <div class="form-group">
                                            <label style="text-align:left;" for="inputName" class="col-sm-3 control-label">Admin Name :</label>
                                            <div class="col-sm-9">
                                                <input type="text" class="form-control" name="admin_name" id="inputName" placeholder="Admin Name" required>
                                            </div>
                                        </div>
										
										 <div class="form-group">
                                            <label style="text-align:left;" for="exampleInputEmail" class="col-sm-3 control-label">Admin Email :</label>
											<div class="col-sm-9">
												  <input type="email" class="form-control" name="admin_email" id="inputEmail" placeholder="Admin Email" required>
											</div>
                                        </div>
										
										   <div class="form-group">
                                            <label style="text-align:left;"  for="exampleInputPassword" class="col-sm-3 control-label">Admin Password :</label>
											<div class="col-sm-9">
												  <input type="password" class="form-control" name="admin_password" id="inputPassword" placeholder="Admin Password" required>
											</div>
                                        </div>
										
										   
                                        </div>
										
					
										
  
                                    </div>
									</div>
									
                                    <!-- /.box-body -->
                                     <div class="box-footer">
									 <div class="form-group">
									<div class="col-sm-3"></div>
									 <div class="col-sm-8">
										 <button type="reset" name="btn_cancel" class="btn btn-danger">Cancel</button>
                                        <button type="submit" name="registeradmin"  class="btn btn-primary" onclick="location.assign('adminlist.php')">Submit</button>
										</div>
										</div>
                                    </div>
									
                                    <!-- /.box-footer -->
                                
								</form>
								</div>
								</div>
								</div>
			</section>


               
            </div>



        
        
