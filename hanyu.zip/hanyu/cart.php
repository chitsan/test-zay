<?php require('header2.php');?>
       <?php

 if(!isset($_SESSION["cus_id"]) ){
       header("location: index.php");
  }
  if(isset($_GET["did"])){
       include_once("product.php");
      	$id=$_GET["did"];
   echo"<script>alert('Your order $id is deleted successfully !');</script>";   
	
		 $_SESSION['cart_items'] = unserialize(serialize($_SESSION['cart_items']));
$item_arr=$_SESSION['cart_items'];
       
            $cart_items2 = array();  
            $product1=null;
            $deleteindex=0;
          foreach ($item_arr as $product){
                         $productid = $product->prodId;
                       $deleteindex++;  
$productname=$product->prodName;

$productprice=$product->prodPrice;
$productimage=$product->productImage;
$productquantity=$product->productQuantity;
if($deleteindex!=$id){
         
  $product1 = new product( $productid,$productname,$productprice,$productimage,$productquantity);
 array_push($cart_items2, $product1);
                       }
    
 
    
}

             
                
               $_SESSION['cart_items']= $cart_items2;
               }   
     
 ?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
         <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
        <title></title>
        <style>
            .table>tbody>tr>td,
.table>tfoot>tr>td {
  vertical-align: middle;
}

@media screen and (max-width: 600px) {
  table#cart tbody td .form-control {
    width: 20%;
    display: inline !important;
  }
  .actions .btn {
    width: 36%;
    margin: 1.5em 0;
  }
  .actions .btn-info {
    float: left;
  }
  .actions .btn-danger {
    float: right;
  }
  table#cart thead {
    display: none;
  }
  table#cart tbody td {
    display: block;
    padding: .6rem;
    min-width: 320px;
  }
  table#cart tbody tr td:first-child {
    background: #333;
    color: #fff;
  }
  table#cart tbody td:before {
    content: attr(data-th);
    font-weight: bold;
    display: inline-block;
    width: 8rem;
  }
  table#cart tfoot td {
    display: block;
  }
  table#cart tfoot td .btn {
    display: block;
  }
}
        </style>
    </head>
    <body>

<div class="container" style="margin-top:100px;height:1000px">
  <table id="cart" class="table table-hover table-condensed">
    <thead>
      <tr>
        <th style="width:50%;font-size:20px;">Product</th>
        <th style="width:10%;font-size:20px;">Price</th>
        <th style="width:8%;font-size:20px;">Quantity</th>
        <th style="width:22%;font-size:20px;" class="text-center">Subtotal</th>
        <th style="width:10%;font-size:20px;"></th>
      </tr>
    </thead>
    <tbody>
               <?php
 include_once("product.php");

if(isset($_SESSION['cart_items'])){
  
     $_SESSION['cart_items'] = unserialize(serialize($_SESSION['cart_items']));
$item_arr=$_SESSION['cart_items'];

$total=0;
$index=0;
          foreach ($item_arr as $product){
             
              $productid = $product->prodId;
$productname=$product->prodName;
$productprice=$product->prodPrice;
$productimage=$product->productImage;
$productquantity=$product->productQuantity;
$subtotal=$productprice*$productquantity;
$total+=$productprice;
$index++;

    ?>

         
      <tr>
   
        <td data-th="Product">
          <div class="row">
              <div class="col-sm-2 hidden-xs">
                 
                  <img  src="pic/<?php echo $productimage; ?>" style="width:150px;height:100px"alt="..." class="img-responsive" /></div>
            <div class="col-sm-10">
              <h4 class="nomargin"><?php echo $productname; ?></h4>
             
            </div>
          </div>
        </td>
        <td data-th="Price"><?php echo $productprice; ?></td>
        <td data-th="Quantity">
           <?php echo $productquantity; ?>
         
        </td>
        <td data-th="Subtotal" class="text-center"><?php echo $subtotal; ?></td>
        <td class="actions" data-th="">
        
        
          <a href='cart.php? did=<?php echo$index?>' class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></a>    
        </td>
      </tr>
    </tbody>
 
      <?php
}


?>
       <tfoot>
      <tr class="visible-xs">
        <td class="text-center"><strong>Total <?php echo $total;  ?></strong></td>
       
      </tr>
      <?php
    }
    ?>
      <tr>
          <td><a href="customer_home.php" class="btn btn-warning"><i class="fa fa-angle-left"></i> Continue Shopping</a></td>
        <td colspan="2" class="hidden-xs"></td>
        <?php
        if(isset($_SESSION['cart_items'])){
            ?>

        <td class="hidden-xs text-center"><strong>Total <?php echo $total; ?></strong></td>
        <?php
        }
        ?>
        <td><a href="checkout.php" class="btn btn-success btn-block">Checkout <i class="fa fa-angle-right"></i></a></td>
      </tr>
    </tfoot>
    
  </table>
</div>
           <hr>

          <div class="w3-container w3-light-blue-grey w3-padding-20" id="contact">
    <h1>Contact</h1><br>
    <p>We offer service for event, wedding or special moment. We understand your needs and we will arrange your needs
        to memorize the biggest moment of life. Do not hesitate to contact us.</p>
    <p class="w3-text-blue-grey w3-large"><b>Hanyu Floral & Gift,Yadanapone Street,Kyeemyintdaine Township,Yangon</b></p>
    <p>You can also contact us by phone +959450017312 or email hanyu@floral.com</p>
    
  </div>
  
<!-- End page content -->
</div>

<!-- Footer -->
<footer class="w3-center w3-light-grey w3-padding-32">
     <p>Created by Chit Chit San</p>
  <p>Powered by <a href="https://www.w3schools.com/w3css/default.asp" title="W3.CSS" target="_blank" class="w3-hover-text-green">w3.css</a></p>
</footer>
        
    </body>
</html>
