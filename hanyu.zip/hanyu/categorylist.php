<?php require('sidemenu.php');
if(!isset($_SESSION["admin_id"]) ){
       header("location: index.php");
  } ?>

<?php

 
 if(isset($_GET["c_id"])){
		$c_id=$_GET["c_id"];
		$statement=$connection->prepare("Delete From category where category_id=?");
		$statement->bind_param("i",$c_id);
		$statement->execute();
		if($statement->error){
		$statement->close();
			echo"<script>alert('Something Wrong in deleting category!.Please Contact to the administrator');</script>";
		}
		else{
		$statement->close();
		
		echo"<script>alert('Category information  is deleted successfully !');location.assign('categorylist.php');</script>";
		}
	}
 ?>

            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
			
			<div class="row">
            <div class="container">
                <div class="table-responsive" style=" overflow:auto;">
                    <table class="table" style="border:2px solid black;">
                        <thead style="background-color: skyblue; color:black;">
                            <tr style="font-size: 1.2em;">
                                <th> Category List</th>                                      
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
			<?php
				$result=$connection->query("Select * from category");
				while($row=$result->fetch_assoc()){
				$category_id = $row["category_id"];
	
			?>
			<tr>
				<td><?php echo $row["category_name"];?></td>
				<td><input type="button" value="Delete" class="btn btn-danger"  onclick="location.assign('categorylist.php?c_id=<?php echo $category_id;?>')"/></td>
			</tr>
			<?php } $result->free(); ?>



                        </tbody>
                    </table>
                </div>
                
                
               
            </div>
        </div>


		


               
            </div>

        
        
