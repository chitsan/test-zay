<?php require('sidemenu.php');
 ?>
<?php
  if (isset($_POST["c_register"])) 
	{
$category_name=$_POST["category_name"];
$statement = $connection ->prepare("Insert Into category(category_name) Values(?)");

        $statement ->bind_param("s",$category_name);
        $statement ->execute();
        if($statement->error)
        {
                $err=$statement ->error;
                echo"<script>alert('$err');</script>";
        }
        else{
                echo "<script>alert('Category is successfully inserted!');</script>";
        }
        $statement ->close();
}
?>
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">                     
                	<div class="content">		
                    <div class="row">
<!-- left column -->
     <div class="col-md-12">
    <!-- Horizontal Form -->
    <div class="box box-info">
        <div class="box-header with-border">
            <h3 class="text-centre">Category Registration Form</h3>
        </div>
          <div class="box-header with-border">
            <h4 class="text-centre">To register new category by inserting new category Name.</h4>
        </div>
        <!-- /.box-header -->
        <!-- form start -->
        <form class="form-horizontal" method='post' enctype="multipart/form-data">
            <div class="box-body">
<div class="col-md-12">
                <div class="form-group">
                    <label style="text-align:left;" for="categoryName" class="col-sm-3 control-label">Category Name :</label>
                    <div class="col-sm-9">
                        <input type="type" class="form-control" name="category_name" id="inputName" placeholder="Category Name" required>
                    </div>
                </div>
										</div>
										             <!-- /.box-body -->
                                     <div class="box-footer">
									 <div class="form-group">
									<div class="col-sm-3"></div>
									 <div class="col-sm-8">
										 <button type="reset" name="btn_cancel" class="btn btn-danger">Cancel</button>
                                       <button type="submit" name="c_register"  class="btn btn-primary" onclick="location.assign('admin_home.php')">Submit</button>
										</div>
										</div>
                                    </div>
									
                                    <!-- /.box-footer -->
                                
								</form>
								</div>
								</div>
								</div>
			</section>

                    </div>
               
            </div>



        
        
