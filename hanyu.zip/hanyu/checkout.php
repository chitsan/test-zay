<?php
require'mysql_connection.php';
session_start();
if(!isset($_SESSION["cus_id"]) ){
       header("location: index.php");
  } 
?>


  <?php

   
     if (isset($_POST["checkout"])) 
	{
          
		# code...
		$cus_id=$_SESSION['cus_id'];
                if(isset($_POST["d_name"])){
                    if(!isset($_POST["d_date"])){
                    echo"<script>alert('Please Choose Delivery Date');</script>";
                     
                    }else  if(!isset($_POST["d_address"])){
                        echo"<script>alert('Please Enter Delivery Address');</script>";
                        
                    }
                    else{
                   $dname=$_POST["d_name"];
                    $ddate=$_POST["d_date"];
                    $daddress=$_POST["d_address"];
                    if(isset($_POST["d_phone"])){
                    $dphone=$_POST["d_phone"];
                     
                    }else{
                         $dphone='';
                    }
                     if(isset($_POST["d_message"])){
                    $dmessage=$_POST["d_message"];
                     
                    }else{
                        $dmessage='';
                    }
                    }
                    $statement = $connection ->prepare("Insert Into delivery (delivery_date,delivery_name,del_address,del_phone,message) Values(?,?,?,?,?)");
		
			$statement ->bind_param("sssss",$ddate,$dname,$daddress,$dphone,$dmessage);
			$statement ->execute();
                        if($statement->error)
			{
				$err=$statement ->error;
				$statement ->close();
				echo"<script>alert('$err');</script>";
			}
			else{			
			  $deli_id =  mysqli_insert_id($connection);
                           
					$statement ->close();
                                        $total=$_SESSION['total'];
                                        $confirmorder="No";
                                        $confirmdelivery="No";
				$statement = $connection ->prepare("Insert Into porder (delivery_id,order_date,order_total,customer_id,confirm_order,confirm_delivery) Values(?,curdate(),?,?,?,?)");
		
			$statement ->bind_param("iiiss",$deli_id,$total,$cus_id,$confirmorder,$confirmdelivery);
			$statement ->execute();
		
			if($statement->error)
			{
				$err=$statement ->error;
				$statement ->close();
				echo"<script>alert('$err');</script>";
			}
			else{			
			 $order_id =  mysqli_insert_id($connection);
                         		$statement ->close();	
                                         include_once("product.php");
                                        if(isset($_SESSION['cart_items'])){
     $_SESSION['cart_items'] = unserialize(serialize($_SESSION['cart_items']));
$item_arr=$_SESSION['cart_items'];
$cus_id=$_SESSION['cus_id'];

          foreach ($item_arr as $product){
              $productid = $product->prodId;

$productprice=$product->prodPrice;

$productquantity=$product->productQuantity;
$subtotal=$productquantity*$productprice;
$statement = $connection ->prepare("Insert Into orderitem (order_id,product_id,oitem_quantity,oitem_price,oitem_subtotal) Values(?,?,?,?,?)");
		
			$statement ->bind_param("iiiii",$order_id,$productid,$productquantity,$productprice,$subtotal);
			$statement ->execute();
		
			if($statement->error)
			{
				$err=$statement ->error;
				$statement ->close();
				echo"<script>alert('$err');</script>";
			}else{
                            $statement = $connection ->prepare("Update product Set product_quantity=product_quantity-$productquantity
                                    Where product_id=$productid");
		
			
			$statement ->execute();
                        if($statement->error)
			{
				$err=$statement ->error;
				$statement ->close();
				echo"<script>alert('$err');</script>";
			}else{
                            echo "<script>alert('Thanks for shopping.We contact you soon!');location.assign('logout.php');</script>";
                        }
                        }
                                        
			}
                      
                                        
                }
		        }	}
                
                }		
        }
     ?>
<!DOCTYPE html>
<html>
<head>
  <title>Payment</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
  <link rel="stylesheet" href="./css/payment.css">
   <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="css/ionicons.min.css">
       <script>
        $(function(){
    var dtToday = new Date();
    
    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate()+1;
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = '0' + day.toString();
    
    var minDate= year + '-' + month + '-' + day;
    
    $('#txtDate').attr('min', minDate);
});
        </script>
</head>
<body>
 
   
  <main class="page payment-page">
<section class="payment-form dark">
  <div class="container">
    <div class="block-heading">
      <h2>Payment</h2>
      <p>You can pay cash on delivery.We will contact you.Thanks for shopping with us.</p>
    </div>
   <form method="post">
      <div class="products">
           <h3 class="title">Checkout</h3>
          <?php
 include_once("product.php");

if(isset($_SESSION['cart_items'])){
     $_SESSION['cart_items'] = unserialize(serialize($_SESSION['cart_items']));
$item_arr=$_SESSION['cart_items'];
$cus_name=$_SESSION['cus_name'];
$cus_phone=$_SESSION['cus_phone'];
$cus_address=$_SESSION['cus_address'];
$cus_email=$_SESSION['cus_email'];
$total=0;
          foreach ($item_arr as $product){
              $productid = $product->prodId;
$productname=$product->prodName;
$productprice=$product->prodPrice;
$productimage=$product->productImage;
$productquantity=$product->productQuantity;
$subtotal=$productquantity*$productprice;
$total+=$productprice;

    ?>
       
        <div class="item">
            
                       
          <span class="price">$<?php echo $subtotal; ?></span>
          
          <p class="item-name"><?php echo $productname; ?></p>
        
        </div>
      
          <?php
}
$_SESSION['total']=$total;
}
?>
        
        <div class="total">Total<span class="price">$<?php echo $total; ?></span></div>
      </div>
         <div class="card-details">
        <h3 class="title">Customer Details</h3>
        <div>
       
                                            <div  class="form-group has-feedback">
                                            Name: <?php echo $cus_name; ?>
                                            </div>
             <div  class="form-group has-feedback">
                                             Phone:  <?php echo $cus_phone; ?>
                                            </div>
             <div  class="form-group has-feedback">
                                              Address:<?php echo $cus_address ?>
                                            </div>
             <div  class="form-group has-feedback">
                                             Email:<?php echo $cus_email ?>
                                            </div>
            
            
            
       </div>

          </div>
      <div class="card-details">
        <h3 class="title">Delivery Details</h3>
        <div>
       <div class="form-group has-feedback">
<input type="text" name="d_name" class="form-control" placeholder="Recipient Name" required>
<br>
       </div>


<div class="form-group has-feedback">
    <textarea name="d_address" id="d_address" placeholder="Delivery  Address" class="form-control" cols="30" rows="5" required></textarea>

</div>
<div class="form-group has-feedback">
<input type="date" id="txtDate" name="d_date" class="form-control" placeholder="Delivery Date" required>
<br>
</div>
<div class="form-group has-feedback">
    <textarea name="d_message" id="message" placeholder="Delivery  Message" class="form-control" cols="30" rows="10" required></textarea>

</div>
            
<div class="form-group has-feedback">
<input type="text" name="d_phone" class="form-control" placeholder="Phone" required>

</div>
              
                   <div class="form-group col-sm-12">
       <button name="checkout" class="btn btn-primary btn-block">Shop</button>
                   </div>
                 
    </div>
              </div>
            </div>
         
     </form>
       
      </div>
    </section>
  </main>
   
</body>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
