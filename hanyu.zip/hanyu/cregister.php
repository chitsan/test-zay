<?php require('header.php');
?>
<?php 

if (isset($_POST["register"])) 
	{
		
		$cus_name=$_POST["cus_name"];
		$cus_email=$_POST["cus_email"];
		$cus_password=$_POST["cus_password"];
		$cus_phone=$_POST["cus_phone"];
		$cus_address=$_POST["cus_address"];
		

		$statement=$connection->prepare("Select * From customer Where customer_email=?");
		$statement->bind_param("s",$cus_email);
		$statement->execute();
		if($statement->fetch()){
			echo"<script>alert(' Sorry!This Email already exist! Select another email and register again!');</script>";
		}
		else{	
		$statement = $connection ->prepare("Insert Into customer(customer_name,customer_email,customer_password,customer_phone,customer_address) Values(?,?,?,?,?)");
		
			$statement ->bind_param("sssss",$cus_name,$cus_email,$cus_password,$cus_phone,$cus_address);
			$statement ->execute();
			if($statement->error)
			{
				$err=$statement ->error;
				echo"<script>alert('$err');</script>";
			}
			else{
				echo "<script>alert('Successfully Register!');location.assign('index.php');</script>";
			}
			$statement ->close();
		}
	}?>

   <div class="container">
        <div class="row">
            <div class="col-md-6">
			<div class="row">
                   
                        <img src="img/rflo.jpg" alt="">
                   
                </div>
			</div>
			<div class="col-md-6">
		
               <div class="login-box" style="margin-top:10em;">

             <div class="panel panel-primary">
                    <div class="panel-heading">
                        <h1 class="text-center">Register</h1>
                    </div>
                    <div class="panel-body">
                        <form name="customer_form" method="post">
                            
                            <div class="form-group has-feedback">
                                <input type="text" name="cus_name" class="form-control" placeholder="Name" required>
                                <span class="glyphicon glyphicon-user form-control-feedback"></span>
                            </div>
							
                            <div class="form-group has-feedback">
                                <input type="email" name="cus_email" class="form-control" placeholder="Email" required>
                                <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                            </div>
                            				
                            <div class="form-group has-feedback">
                                <input type="text" name="cus_phone" class="form-control" placeholder="Phone" required>
                                <span class="glyphicon glyphicon-earphone form-control-feedback"></span>
                            </div>
					
							
							<div class="form-group has-feedback">
                                <input type="password" name="cus_password" class="form-control" placeholder="Password" required>
                                <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                            </div>
				

                            <div class="form-group has-feedback">
                                <textarea name="cus_address" id="address" placeholder="Current Address" class="form-control" cols="30" rows="10" required></textarea>
                                <span class="glyphicon glyphicon-home form-control-feedback"></span>
                            </div>
							
                          
                            <div class="row">
                                
                            
                                <div class="row">
								<div class="col-md-6"><button type="reset" name="btn_cancel" class="btn btn-primary btn-block btn-flat">Cancel</button></div>
                                <div class="col-md-6"><button type="submit" name="register" class="btn btn-primary btn-block btn-flat">Register</button></div>
                                </div>
                               
                            </div>
                        </form>
          
            </div>
            </div>
			</div>
			
			
			
			
            </div>
			
      
			
	</div>
   

</body>
</html>