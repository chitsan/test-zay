
<?php 
require'header2.php';
session_start();

if(!isset($_SESSION["cus_id"]) ){
       header("location: index.php");
  }     
?>
<style>
    .card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.price {
  color: grey;
  font-size: 14px;
}

</style>


<div style="margin-top:50px;">
<header class="w3-display-container w3-content " style="max-width:1600px;min-width:300px" id="home">
  <img class="w3-image" src="./img/Hanyu_header.jpg" alt="Hamburger Catering" width="1600" height="10">
  <div class="w3-display-bottomleft w3-padding-large w3-opacity">
   
  </div>
</header>
    <div style="margin-top:50px;">
<table cellspacing="30" cellpadding="30">
<tr>
<td valign="top"><div    <div style="width:220px; height:250px; float:left; margin-left:20px; margin-top:5px;
                 font-size:15px;">
            <ul style="list-style-type:none"> 
            <li class="active"><a href='customer_home.php' style="font-size:20px; "  class="btn btn-primary"><b> All</b></a></li><br>
                      <?php
                        $result=$connection->query("Select * From category");
                        while($row=$result->fetch_assoc()){
                                $id = $row["category_id"];
                ?>
                         <li> <a href="customer_home.php?cid=<?php echo $row['category_id']; ?>" class="btn btn-primary" >
                <?php echo $row["category_name"];?></b></li></a><br>
                <?php
                        }
                        $result->free();
                ?>
            </ul>
                </div>
</td>


<td>
<form name="frm1" method="POST">
<?php
                if(isset($_GET["cid"])){
                        $cid=$_GET["cid"];
                        $result=$connection->query("Select * From product p, category c
                                                                                Where c.category_id = p.category_id and c.category_id='$cid'");
                        }
                        else{
                $result=$connection->query("Select * From product p, category c
                                                                                Where p.category_id = c.category_id");
                }

                while($row=$result->fetch_assoc()){
                $p_id = $row["product_id"];	

        ?>
                  <div style="width:220px; height:250px; float:left; margin-left:20px; margin-top:30px;
                 font-size:15px;">





<div class="card">
    <a href='viewproduct.php?pid=<?php echo $row['product_id']; ?>" >' style="font-size:20px; ">
        <img src="pic/<?php echo $row['product_image']; ?>" style="width:200px; height:170px; margin-top:10px;"/></a>
        <div style="margin-bottom: 5px;">
        <b><?php echo $row["product_name"]; ?></b>
        </div>
   
  <p class="price"><?php echo $row["product_price"]; ?> $</p>
 
</div>




</div>
<?php
}
$result->free();
?>
</form>				
</td>

</div>

</tr>

</table>  


               
            </div>
    <hr>

          <div class="w3-container w3-light-blue-grey w3-padding-20" id="contact">
    <h1>Contact</h1><br>
    <p>We offer service for event, wedding or special moment. We understand your needs and we will arrange your needs
        to memorize the biggest moment of life. Do not hesitate to contact us.</p>
    <p class="w3-text-blue-grey w3-large"><b>Hanyu Floral & Gift,Yadanapone Street,Kyeemyintdaine Township,Yangon</b></p>
    <p>You can also contact us by phone +959450017312 or email hanyu@floral.com</p>
    
  </div>
  
<!-- End page content -->
</div>

<!-- Footer -->
<footer class="w3-center w3-light-grey w3-padding-32">
     <p>Created by Chit Chit San</p>
  <p>Powered by <a href="https://www.w3schools.com/w3css/default.asp" title="W3.CSS" target="_blank" class="w3-hover-text-green">w3.css</a></p>
</footer>
        
