<?php require('sidemenu.php');?>

            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
			
			 <section class="content">
                    <div class="row">
                        <!-- left column -->
                             <div class="col-md-12">
                            <!-- Horizontal Form -->
                            <div class="box box-info">
                                <div class="box-header with-border">
                                    <h3 class="text-centre">Daily Delivery Report</h3>
                                </div>
                                <!-- /.box-header -->
                                <!-- form start -->
                                <form class="form-horizontal" method='post' enctype="multipart/form-data">
<div class="box-body">
                                    <div class="col-md-12">

                                               <div class="form-group">
        <label style="text-align:left;"  for="exampleInputDate" class="col-sm-3 control-label"> Date:</label>
                                                    <div class="col-sm-9">
                                                             <input type="date" name="report_date" class="form-control" id="inputDate" required>
                                                    </div>
    </div>


                                            </div>

                                    </div>
<!-- /.box-body -->
 <div class="box-footer">
                                     <div class="form-group">
                                    <div class="col-sm-3"></div>
                                     <div class="col-sm-8">
    <button type="submit" name="btn_sales"  class="btn btn-primary" onclick="location.assign('dailyorder.php')">View Report</button>
                                             <button type="button" name="btn_cancel"  class="btn btn-danger" onclick="location.assign('viewreport.php')">Cancel</button>
                                            </div>
                                            </div>
                                    </div>
									
                                    <!-- /.box-footer -->
                                
								</form>
		<?php
			if(isset($_POST["btn_sales"])) {
		?>						
		<div class="row">
            <div class="container">
                <div class="table-responsive" style=" overflow:auto; height:700px;">
                    <table class="table" style="border:2px solid black;width:96%;">
                        <thead style="background-color: skyblue; color:black;">
                            <tr style="font-size: 1.2em;">
                                <th>Customer Name</th>                   
                                <th>Customer Phone</th>
                                <th>Delivery Name</th>
                                <th>Delivery address</th>   
                                <th>Delivery Phone</th>
                                <th>Delivery Message</th>                       
                            </tr>
                        </thead>
                        <tbody>
			<?php
				$rdate = $_POST["report_date"];
				$result=$connection->query("Select c.customer_name,c.customer_phone,d.delivery_name,d.del_address,
                                    d.del_phone,d.message
                                     from customer c,porder p,delivery d
                                     Where c.customer_id=p.customer_id
					And d.delivery_id=p.delivery_id					
                                     And d.delivery_date = '$rdate'");
				while($row=$result->fetch_assoc()){
				
	
			?>
			<tr>
				<td><?php echo $row["customer_name"];?></td>
				<td><?php echo $row["customer_phone"];?></td>
				<td><?php echo $row["delivery_name"];?></td>
				<td><?php echo $row["del_address"];?></td>
				<td><?php echo $row["del_phone"];?></td>
                                <td><?php echo $row["message"];?></td>
				
			</tr>
			<?php } $result->free(); ?>



                        </tbody>
                    </table>
                </div>
                
                
               
            </div>
        </div>
			<?php } ?>						
								</div>
								</div>
								</div>
			</section>

		


               
            </div>



        
        
