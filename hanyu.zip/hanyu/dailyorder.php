<?php require('sidemenu.php');?>

            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
			
			 <section class="content">
                    <div class="row">
                        <!-- left column -->
                             <div class="col-md-12">
                            <!-- Horizontal Form -->
                            <div class="box box-info">
                                <div class="box-header with-border">
                                    <h3 class="text-centre">Daily Order Report</h3>
                                </div>
                                <!-- /.box-header -->
                                <!-- form start -->
                                <form class="form-horizontal" method='post' enctype="multipart/form-data">
<div class="box-body">
                                    <div class="col-md-12">

                                               <div class="form-group">
        <label style="text-align:left;"  for="exampleInputDate" class="col-sm-3 control-label"> Date:</label>
                                                    <div class="col-sm-9">
                                                             <input type="date" name="report_date" class="form-control" id="inputDate" required>
                                                    </div>
    </div>


                                            </div>

                                    </div>
<!-- /.box-body -->
 <div class="box-footer">
                                     <div class="form-group">
                                    <div class="col-sm-3"></div>
                                     <div class="col-sm-8">
    <button type="submit" name="btn_sales"  class="btn btn-primary" onclick="location.assign('dailyorder.php')">View Report</button>
                                             <button type="button" name="btn_cancel"  class="btn btn-danger" onclick="location.assign('viewreport.php')">Cancel</button>
                                            </div>
                                            </div>
                                    </div>
									
                                    <!-- /.box-footer -->
                                
								</form>
		<?php
			if(isset($_POST["btn_sales"])) {
		?>						
		<div class="row">
            <div class="container">
                <div class="table-responsive" style=" overflow:auto; height:700px;">
                    <table class="table" style="border:2px solid black;width:96%;">
                        <thead style="background-color: skyblue; color:black;">
                            <tr style="font-size: 1.2em;">
                                <th style="text-align:center">Order Item Image</th>                   
                                <th style="text-align:center">Order Item Name</th>
                                <th style="text-align:center">Order Item Price</th>
                                <th style="text-align:center">Order Item Quantity</th>   
                                <th style="text-align:center">Total Amount</th>                       
                            </tr>
                        </thead>
                        <tbody>
			<?php
				$rdate = $_POST["report_date"];
				$result=$connection->query("Select p.product_id,p.product_name,i.oitem_quantity,i.oitem_price,p.product_image
                                    ,i.oitem_subtotal from orderitem i,product p, porder o
											Where  o.order_id=i.order_id
                                                                                        And i.product_id=p.product_id
                                                                                        And o.order_date = '$rdate'");
				while($row=$result->fetch_assoc()){
				$i_id = $row["product_id"];
	
			?>
			<tr>
				<td style="text-align:center"><img src="pic/<?php echo $row['product_image'];?>" style="width: 70px; height: 60px;" /></td>
				<td style="text-align:center"><?php echo $row["product_name"];?></td>
				<td style="text-align:center"><?php echo $row["oitem_price"];?>$</td>
				<td style="text-align:center"><?php echo $row["oitem_quantity"];?></td>
				<td style="text-align:center"><?php echo $row["oitem_subtotal"];?>$</td>
				
			</tr>
			<?php } $result->free(); ?>



                        </tbody>
                    </table>
                </div>
                
                
               
            </div>
        </div>
			<?php } ?>						
								</div>
								</div>
								</div>
			</section>

		


               
            </div>


        
        
