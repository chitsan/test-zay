<?php
$c=new mysqli("localhost","root","","",3306);
$result=$c->multi_query("Create database hanyu_ccs;
     Use hanyu_ccs;
     Create Table admin(
     admin_id int Primary Key auto_increment,
     admin_name varchar(30) Not Null,
     admin_password varchar(20) Not Null,
     email varchar(30) Not Null);
     
Insert into admin(admin_id,admin_name,admin_password,email) 
values(1,'hanyu','123!@#!@#','hanyu@gmail.com');
Insert into admin(admin_id,admin_name,admin_password,email) 
values(2,'chit','123!@#!@#','chitsanchitsan1@gmail.com');

     Create Table customer(
     customer_id int Primary Key auto_increment,
     customer_name varchar(30) Not Null,
     customer_password varchar(20) Not Null,
     customer_email varchar(30) Not Null,
     customer_phone int Not Null,
     customer_address varchar(100)Not Null);
     Insert into customer values(1,'Thet Hnin Aye','1234','thet@gmail.com','090909888','Yangon,Hlaing');
        Insert into customer values(2,'Ni lar Win','1234','ni@gmail.com','090449888','Yangon,Kan Street');
           Insert into customer values(3,'Yamin','1234','yamin@gmail.com','090349888','Yangon,MICT park');
              Insert into customer values(4,'Win Win Nyein','1234','win@gmail.com','090909888','Yangon,downtown');
    Create Table category(
    category_id int Primary Key auto_increment,
    category_name varchar(50) Not Null);
    
    Insert into category(category_name) values('designer collection');
    Insert into category(category_name) values('autumn collection');
    Insert into category(category_name) values('romantic collection');
     
    Create Table product(
     product_id int Primary Key auto_increment,
     product_name varchar(300) Not Null,
     product_price int Not Null,
     product_description varchar(300) Not Null,
     product_image varchar(300)Not Null,
     category_id int Not Null,
     product_quantity int Not Null,
     foreign key(category_id) References category(category_id));
    
Insert into product(product_name,product_price,product_description,product_image,category_id,product_quantity)
     values('Pretty Please',25,'With a mix of everything pretty, the Pretty Please bouquet is great to give to any occasion. A mixture of wonderful colors, from a fairly light pink to bright green, lovely lavender and clean white, all tied up with a bright pink bow. The color and flower combinations makes this bouquet one of our most popular 
     - and for good reason! These flowers will bring a smile to someone\'s face and be the highlight of their day! ',
     'f1.jpg',1,20);# 1 row affected.

      Insert into product(product_name,product_price,product_description,product_image,category_id,product_quantity)
     values('Teleflora Autumn Bouquet',25,'Bring the beauty of the outdoors in with this wildly wondrous bouquet, featuring the classic hues of autumn arranged in 
     a birch tree-inspired cube that\'s adorned with twine and shimmering metal leaf charms. ',
     'f2.jpg',2,20);# 1 row affected.

      Insert into product(product_name,product_price,product_description,product_image,category_id,product_quantity)
     values('You\'re Special Bouquet',22,'Sometimes you need to remind those of just how much they truly mean to you. Vibrant roses, rich snapdragons, and bronzed pompons come together to do just that in a frosted amber glass vase within a bronze metal lantern. You don\'t always need a holiday to give it, you simply need someone special to give it to.',
     'f3.jpg',3,20);# 1 row affected.

      Insert into product(product_name,product_price,product_description,product_image,category_id,product_quantity)
     values('Rose & Lily Celebration',65,'Send stunning flowers to celebrate any occasion!
     With classic floral colors including red roses and pink lilies the Rose and Lily
     Celebration is a wonderful gift to send to a friend or family member for a birthday,
     get well or anniversary. The flowers are arranged by hand at a local florist shop.
     The floral artist creates the Rose and Lily bouquet with red roses, pink roses, pink lilies,
     pink alstroemeria and purple wax flowers. 
     Paired with the flowers is a keepsake clear vase that is wrapped in a decorative ribbon. ',
     'f1.jpg',1,20);# 1 row affected.

      Insert into product(product_name,product_price,product_description,product_image,category_id,product_quantity)
     values('Be My Love Bouquet',45,'Add some romance with this rich arrangement of luxurious flowers
     in classic winter colors gathered in a ruby red vase she\'ll use for any occasion! ',
     'f2.jpg',2,20);# 1 row affected.

      Insert into product(product_name,product_price,product_description,product_image,category_id,product_quantity)
     values('Golden Autumn',35,'This radiant bouquet is beautiful and complex,
     just like the season itself. Made up of yellow roses,
     bronze daisy pompons, and red alstroemeria, set in a clear glass vase,
     the Golden Autumn bouquet truly brings out the best of fall. GOOD bouquet is approx.',
     'f3.jpg',3,20);# 1 row affected.

      Insert into product(product_name,product_price,product_description,product_image,category_id,product_quantity)
     values('Pure Happiness Bouquet',25,'Our rustic, easy bouquet in shades of blue and white captures every wish you want to express to those who mean the most.
     Hand-designed inside a clear cylinder vase, it’s a gift that won’t leave them wondering how you much you care. ',
     '3.jpg',1,20);# 1 row affected.

      Insert into product(product_name,product_price,product_description,product_image,category_id,product_quantity)
     values('Our Sweet Romance',45,'People will stop and stare at this bouquet. 
     The Stunning Beauty deserves its name, as it is both elegant and unique, guaranteed to be a crowd pleaser. With rich red roses surrounded by pretty pink lilies this arrangement
     delivers that special message to someone you care for, letting them know you\'re thinking of them.  ',
     '4.jpg',2,20);# 1 row affected.

      Insert into product(product_name,product_price,product_description,product_image,category_id,product_quantity)
     values('Cotton Candy',25,'Sweet as candy! This soft pink and white bouquet is a feminine choice for any occasion.Includes
     Stems: Pink and white flowers including roses, miniature carnations and button spray chrysanthemums',
     'flo3.jpg',3,20);# 1 row affected.

      Insert into product(product_name,product_price,product_description,product_image,category_id,product_quantity)
     values('Let\'s Sail Away Bouquet',25,'Picked fresh from the farm, our Let\'s Sail Away Bouquet has a chic Mediterranean color and styling that your special recipient will love. Hand gathered at select floral farms,
     this bouquet brings together hot pink blooms with contrasting blue blossoms to create an eye-catching display.  ',
     'flo4.jpg',1,20);# 1 row affected.

      Insert into product(product_name,product_price,product_description,product_image,category_id,product_quantity)
     values('The Sunrise Bouquet',25,'Gushing with vibrant colors, 
     this unique flower arrangement resembles the morning sky. The Sunrise Bouquet
     is sure to bring any home or office to life with its hot pinks, sweet yellows, 
     pretty purples and its generous cascade of greens.
     This noteworthy flower arrangement is becomes even more special during 
     the spring and summer months, as weather compliments its warmth.',
     'f4.jpg',2,20);# 1 row affected.

      Insert into product(product_name,product_price,product_description,product_image,category_id,product_quantity)
     values('Truth Be Bold Bouquet',45,'Picked fresh from the farm, the Truth Be Bold Bouquet offers a bright mix of color to brighten up your special recipient\'s home or office this harvest season! Hand gathered at select floral farms, this fresh flower bouquet brings together a mix of greens, reds, and blues to create an impressive display. Picked fresh for you, this stunning fall bouquet is ready to help you send your warmest wishes in honor of a birthday,
     Thanksgiving, or to extend your thanks and gratitude to friends and family near and far. ',
     'f5.jpg',3,20);# 1 row affected.


    Create table delivery(
    delivery_id int Primary Key auto_increment,
    delivery_date date Not Null,
    delivery_name varchar(50)Not Null,
    del_address varchar(300)Not Null,
    del_phone varchar(30) Not Null,
    message varchar(500)Not Null);

     
   Create table porder(
    order_id int Primary Key auto_increment,
    delivery_id int,
    order_date date Not Null,
    order_total int Not Null,
    customer_id int Not Null,
  
    confirm_order varchar(20) ,
    confirm_delivery varchar(20) ,
    foreign key(delivery_id) References delivery(delivery_id),
    foreign key(customer_id) References customer(customer_id)
  );
     
     Create table orderitem(
     oitem_id int Primary Key auto_increment,
     order_id int Not Null,
     package_id int Not Null,
     oitem_quantity int Not Null,
     oitem_price int Not Null,
     oitem_subtotal int Not Null,
     foreign key(order_id) References porder(order_id),
     foreign key(package_id) References package(package_id)
  );
     

    Create table review(
    review_id int Primary Key auto_increment,
    review_content varchar(800) Not Null,
    review_date date Not Null,
    customer_id int,
    admin_id int,
     foreign key(customer_id) References customer(customer_id),
       foreign key(admin_id) References admin(admin_id));
     
INSERT INTO review(review_id,review_content,review_date,customer_id) VALUES 
  (1, 'The florist has great skill and really satigying !', '2018-07-04 15:42:51',1);
  INSERT INTO review(review_id,review_content,review_date,admin_id) VALUES 
  (2,'Thank you for Your review!', '2018-08-04 15:50:55',1);
  INSERT INTO review(review_id,review_content,review_date,customer_id) VALUES 
  ( 3,'It is really cool !!', '2018-05-04 20:12:01',2);

     
        ");

