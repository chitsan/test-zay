<?php require('header.php');
session_unset();
session_destroy();?>
<div class="container">
<header class="w3-display-container w3-content w3-wide" style="max-width:1500px;" id="home">
  <img class="w3-image" src="./img/index.jpg" alt="" width="1500" height="800">
  <div class="w3-display-middle w3-margin-top w3-center">
  
  </div>
</header>
</div>
 <hr id="about">

  <!-- About Section -->
  <div class="w3-container w3-padding-32 w3-center">  
    <h3>About Us</h3><br>
    <img src="./img/flower8.jpg" alt="Me" class="w3-image" style="display:block;margin:auto" width="800" height="533">
    <div class="w3-padding-32">
      <h4><b>The best floral shop in town!</b></h4>
      <h6><i>With Passion For Your Happiest Moment</i></h6>
      <p>Opened in 2010 and still with new ideas and flowers everyday.
          We want to share with your moment.With flowers and gifts,
          we believe everyone get happiest moment and they can 
          enjoy their life.
      </p>
    </div>
  </div>

   <hr>

          <div class="w3-container w3-light-blue-grey w3-padding-20" id="contact">
    <h1>Contact</h1><br>
    <p>We offer service for event, wedding or special moment. We understand your needs and we will arrange your needs
        to memorize the biggest moment of life. Do not hesitate to contact us.</p>
    <p class="w3-text-blue-grey w3-large"><b>Hanyu Floral & Gift,Yadanapone Street,Kyeemyintdaine Township,Yangon</b></p>
    <p>You can also contact us by phone +959450017312 or email hanyu@floral.com</p>
    
  </div>
  
<!-- End page content -->
</div>

<!-- Footer -->
<footer class="w3-center w3-light-grey w3-padding-32">
     <p>Created by Chit Chit San</p>
  <p>Powered by <a href="https://www.w3schools.com/w3css/default.asp" title="W3.CSS" target="_blank" class="w3-hover-text-green">w3.css</a></p>
</footer>
        

</body>
</html>