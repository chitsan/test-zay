<?php require('header.php');?>

<?php

if (isset($_POST["login"])) {
    $l_email=$_POST["email"];
    $l_password=$_POST["password"];
        
    $result = $connection -> query("Select * From customer Where customer_email='$l_email' And customer_password='$l_password'");
	$admin = $connection -> query("Select * From admin Where email='$l_email' And admin_password='$l_password'");
    if ($row=$result -> fetch_assoc()) {
        $_SESSION['cus_id']=$row['customer_id'];
        $_SESSION['cus_name']=$row['customer_name'];
        $_SESSION['cus_email']=$row['customer_email'];
		$_SESSION['cus_password']=$row['customer_password'];
        $_SESSION['cus_phone']=$row['customer_phone'];
		$_SESSION['cus_address']=$row['customer_address'];
        echo "<script>alert('Successfully Login!');location.assign('customer_home.php');</script>";
    } 
	
	else if($row=$admin -> fetch_assoc()){
       
		$_SESSION['admin_id']=$row['admin_id'];
        $_SESSION['admin_name']=$row['admin_name'];
        $_SESSION['admin_email']=$row['email'];
        

        echo "<script>alert('Success  Login as Admin!');location.assign('admin_home.php');</script>";
	}
	else {
        echo "<script>alert('Login Fail!');</script>";
    }
}
?>

   <div class="container">
        <div class="row">
            <div class="col-md-6">
			<div class="row">
                     <div class="w3-display-container">
                        <img src="img/lflo.jpg" alt="">
                     </div>
                </div>
			</div>
			<div class="col-md-6">
		
               <div class="login-box" style="margin-top:10em;">

            <!-- /.login-logo -->
            <div class="panel-body">


                <form action="#" method="post" >
                    <h1 class="text-center">Login</h1>
                    <div class="form-group has-feedback">
                        <input type="email" class="form-control" name="email" placeholder="Email">
                        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                    </div>
                    <div class="form-group has-feedback">
                        <input type="password" class="form-control"  name="password" placeholder="Password">
                        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                    </div>
                    <div class="row">


                        <!-- /.col -->
                        <div class="col-xs-12">
                            <button type="submit" name="login" class="btn btn-primary btn-block btn-flat">Log In</button>
                        </div>
                        <!-- /.col -->






                    </div>
                </form>
                <!-- /.login-box-body -->
            </div>
            </div>
			</div>
			
			
			
			
            </div>
			
      
			
	</div>
   

</body>
</html>