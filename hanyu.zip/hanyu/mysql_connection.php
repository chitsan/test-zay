<?php
	$dblink= "localhost";
	$dbname="hanyu_ccs";
	$dbusername="root";
	$dbpassword="";
	$dbportno=3306;


	$connection= new mysqli("localhost","root","@J^+mqBrhw{7","hanyu_ccs",3306);
	if($connection->connect_error){
		die($connection->connect_error);
	}

?>