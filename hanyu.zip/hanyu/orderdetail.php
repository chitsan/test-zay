
<?php require('sidemenu.php');?>


<?php

if(isset($_POST["modify"])){
	
	$c_order=$_POST["confirm_order"];
        $d_deliver=$_POST["confirm_delivery"];
        $statement =$connection ->prepare ("Update porder Set confirm_order=?,confirm_delivery=? Where order_id=?");
	$statement->bind_param("ssi",$c_order,$d_deliver,$_GET["o_id"]);
				
				
				$statement ->execute();
				 if ($statement ->error){
				 	$statement ->close();
				 	echo "<script> alert ('Sorry your modification is not successful! Please try again !');</script>";
				 }
				 else
				 {
				 	$statement ->close ();
				
				echo "<script> alert('Modification Successful !');location.assign('vieworderlist.php');</script>";
				 }
			}


if(isset($_GET["o_id"])){
		$o_id=$_GET["o_id"];
		
		$statement=$connection->prepare("select * from porder where order_id=?");
										
		$statement->bind_param("i",$o_id);
		$statement->execute();
		$statement->bind_result($order_id,$delivery_id,$order_date,$order_total,$customer_id,$confirm_order,$confirm_delivery);
		$statement->fetch();
		$statement->close();
		
	
        $statement=$connection->prepare("select customer_name,customer_email,customer_phone,customer_address from customer where customer_id=?");
        $statement->bind_param("i",$customer_id);
		$statement->execute();
                $statement->bind_result($customer_name,$customer_email,$customer_phone,$customer_address);
		$statement->fetch();
		$statement->close();
               



           ?>
            <div class="content-wrapper">

<section class="content">
<div class="row">
<!-- left column -->
    <div class="col-md-12">
   <!-- Horizontal Form -->
   <div class="box box-info">
<div class="box-header with-border">
    <h3 class="text-centre">Order  Form</h3>
</div>
<!-- /.box-header -->
<!-- form start -->
 <form class="form-horizontal" method='post' enctype="multipart/form-data">
    <div class="box-body">
                                        <div>

                                                 <div class="form-group">
            <label style="text-align:left;" for="exampleInputName" class="col-sm-4 control-label">Customer Name </label>
                                                        <div class="col-sm-9">
                                                                 <?php echo $customer_name;?>
                                                        </div>
        </div>

                                                 <div class="form-group">
            <label style="text-align:left;" for="exampleInputEmail" class="col-sm-4 control-label">Customer Email </label>
                                                        <div class="col-sm-9">
                                                                  <?php echo $customer_email;?>
                                                        </div>
        </div>

										 <div class="form-group">
                                            <label style="text-align:left;" for="exampleInputAddress" class="col-sm-4 control-label">Customer Address </label>
											<div class="col-sm-9">
												 <?php echo $customer_address;?>
											</div>
                                        </div>
                <table class="table-bordered" style="width:50%">
<thead>
<tr>

<th>Poduct ID</th>
<th>Product Name</th> 
<th>Quantity</th>
<th>Price</th>
<th>Subtotal</th>


</thead>
<tbody>
<?php
$o_id=$_GET["o_id"];

$s=$connection->prepare("Select p.product_name,oi.product_id,
        oi.oitem_price,oi.oitem_quantity,oi.oitem_subtotal from orderitem oi,product p
        where p.product_id=oi.product_id and oi.order_id=?");
$s->bind_param("i",$o_id);
$s->execute();
$s->bind_result($productname,$productid,$price,$quantity,$subtotal);

while($s->fetch()){
echo"<tr>
    <td>$productid</td>
<td>$productname</td>
<td>$price</td>
<td>$quantity</td>
<td>$subtotal</td>
    
</tr>";
}
$s->close();

?>

                </table>
                                            <?php
                      $o_id=$_GET["o_id"];  
                      
      
	$s=$connection->prepare("Select confirm_order,confirm_delivery from porder where order_id=?");
$s->bind_param("i",$o_id);
$s->execute();
$s->bind_result($confirm_order,$confirm_delivery);

if($s->fetch()){
            

    ?>
                                            <hr>                         
<label>Confirm Order         :</label><select name="confirm_order">
  <option value="Yes" 
      <?php if ($confirm_order == 'Yes') echo ' selected="selected"'; ?>>Yes</option>
  <option value="No"
           <?php if ($confirm_order == 'No') echo ' selected="selected"'; ?>>No</option>
  
</select><br><br>
<label>Confirm Delivery         :</label><select name="confirm_delivery">
  <option value="Yes" 
      <?php if ($confirm_delivery == 'Yes') echo ' selected="selected"'; ?>>Yes</option>
  <option value="No"
           <?php if ($confirm_delivery == 'No') echo ' selected="selected"'; ?>>No</option>
  
</select>
<hr>
    <?php
}
$s->close();
$connection->close();
?>									

</div>



</div>

<!-- /.box-body -->
<div class="box-footer">
<div class="form-group">
<div class="col-sm-3"></div>
<div class="col-sm-8">
 <button type="reset" name="btn_cancel" class="btn btn-danger" onclick="location.assign('vieworderlist.php')">Cancel</button>
<button type="submit" name="modify"  class="btn btn-primary">Modify</button>
</div>
										</div>
                                    </div>
	
                                            <?php
}
                                            ?>								
                                    <!-- /.box-footer -->
                                
								</form>
								</div>
								</div>
								</div>
			</section>


               
            </div>


        
        

        
