<?php require('sidemenu.php');?>

            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
			
			 <section class="content">
                    <div class="row">
                        <!-- left column -->
                             <div class="col-md-12">
                            <!-- Horizontal Form -->
                            <div class="box box-info">
                                <div class="box-header with-border">
                                    <h3 class="text-centre"> Popular Products</h3>
                                </div>
                                <!-- /.box-header -->
                                <!-- form start -->
                                <form class="form-horizontal" method='post' enctype="multipart/form-data">
								

<!-- /.box-body -->
<div class="box-footer">
<div class="form-group">
<div class="col-sm-3"></div>

</div>
                                 </div>

                                 <!-- /.box-footer -->

                                                             </form>
            					
             <div class="row">
         <div class="container">
             <div class="table-responsive" style=" overflow:auto; height:700px;">
                 <table class="table" style="border:2px solid black; width:96%;">
                     <thead style="background-color: skyblue;color:black;">
                         <tr style="font-size: 1.2em;">
                             <th>Product Image</th>                   
                             <th>Product Name</th>
                                                             <th>Category</th>
                                                             <th>Price</th>
                             <th>Total Order</th>                  
                         </tr>
                     </thead>
                     <tbody>
                     <?php
                         
                             $result=$connection->query("Select p.product_image,p.product_name,c.category_name,
                                 i.oitem_price, SUM(i.oitem_quantity) as qty
                                                                                     from orderitem i, category c,product p                                                                                 
                                                                                     Where  
                                                                                    p.product_id=i.product_id
                                                                                     And p.category_id=c.category_id
                                                                                     GROUP BY p.product_id
                                                                                     ORDER BY SUM(i.oitem_quantity) desc LIMIT 10");
                             while($row=$result->fetch_assoc()){
                             //$i_id = $row["i_id"];

                     ?>
                     <tr>
                             <td><img src="pic/<?php echo $row['product_image'];?>" style="width: 70px; height: 60px;" /></td>
                             <td><?php echo $row["product_name"];?></td>
                             <td><?php echo $row["category_name"];?></td>
                             <td><?php echo $row["oitem_price"];?></td>
                             <td><?php echo $row["qty"];?></td>

                     </tr>
                     <?php } $result->free(); ?>



                     </tbody>
                 </table>
             </div>



         </div>
     </div>
                 					
                                                             </div>
                                                             </div>
                                                             </div>
                     </section>





         </div>



        
