<?php

class product {
    
  public $prodId;
  public $prodName;
  public $prodPrice;
  public $productImage;
  public $productQuantity;

  public function __construct($prodId, $prodName, $prodPrice,$productImage,$productQuantity) {
    $this->prodId    = $prodId;
    $this->prodName  = $prodName;
    $this->prodPrice = $prodPrice;
    $this->productImage=$productImage;
    $this->productQuantity=$productQuantity;
  }

  public function get_prodId() {
    return $this->prodId;
  }

  public function get_prodName() {
    return $this->prodName;
  }

  public function get_prodPrice() {
    return $this->prodPrice;
  }
  public function get_productImage() {
    return $this->productImage;
  }
  public function get_productQuantity(){
      return $this->productQuantity;
  }
}
