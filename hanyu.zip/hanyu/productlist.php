<?php require('sidemenu.php');?>


<?php

 
 if(isset($_GET["d_pid"])){
		$p_id=$_GET["d_pid"];
		$statement=$connection->prepare("Delete From product where product_id=?");
		$statement->bind_param("i",$p_id);
		$statement->execute();
		if($statement->error){
		$statement->close();
			echo"<script>alert('Something Wrong in deleting product.Please contact to the administrator!');</script>";
		}
		else{
		$statement->close();
		$files=glob($_SERVER["DOCUMENT_ROOT"]."/hanyu/pic/".$p_id. ".*");
		foreach ($files as $file){
			unlink($file);
		}
		echo"<script>alert('Your item is deleted successfully !');location.assign('productlist.php');</script>";
		}
	}
 ?>



            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
			<div class="row">
            <div class="container">
                <div class="table-responsive" style=" overflow:auto;">
                    <table class="table" >
                        <thead style="background-color: skyblue; color:black;">
                            <tr style="font-size: 1.2em;">
                                <th style="text-align: center">Name</th>                   
                                <th style="text-align: center">Image</th>
                                <th style="text-align: center">Category</th>   
                                <th style="text-align: center">Description</th>   
                                <th style="text-align: center">Price</th>    
                               
								<th>Quantity</th>                    
                                <th class="text-center" colspan="2">Action</th>
                            </tr>
                        </thead>
                        <tbody>
			<?php
				$result=$connection->query("Select * from product p, category c
											where p.category_id=c.category_id");
				while($row=$result->fetch_assoc()){
				$p_id = $row["product_id"];
	
			?>
			<tr>
				<td><?php echo $row["product_name"];?></td>
				<td><img src="pic/<?php echo $row['product_image'];?>" style="width: 70px; height: 60px;" /></td>
				<td><?php echo $row["category_name"];?></td>
				<td><?php echo $row["product_description"];?></td>
				<td><?php echo $row["product_price"];?>$</td>
				
				<td><?php echo $row["product_quantity"];?></td>
				<td><input type="button" value="Update" class="btn btn-success" onclick="location.assign('updateproduct.php?u_pid=<?php echo $p_id;?>')"/></td>
				<td><input type="button" value="Delete" class="btn btn-danger" onclick="location.assign('productlist.php?d_pid=<?php echo $p_id;?>')"/></td>
			</tr>
			<?php } $result->free(); ?>



                        </tbody>
                    </table>
                </div>
                
                
               
            </div>
        </div>


		


               
            </div>



        
        
