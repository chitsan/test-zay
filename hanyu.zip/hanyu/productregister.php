<?php require('sidemenu.php');?>
			
			
			

<?php

  if (isset($_POST["pro_register"])) 
	  
	{	
		$p_name=$_POST["prductname"];
		$p_image=$_FILES["p_image"]["name"];
		$p_describe=$_POST["p_describe"];
		$p_price=$_POST["p_price"];
                $p_quantity=$_POST["p_quantity"];
                $cat_id=$_POST["category_id"];
		
			
		
		

$statement = $connection ->prepare("Insert Into product(product_name,product_price,product_description,"
        . "product_image,category_id,product_quantity) Values(?,?,?,?,?,?)");

        $statement ->bind_param("sissii",$p_name,$p_price,$p_describe,$p_image,$cat_id,$p_quantity);
        $statement ->execute();
        move_uploaded_file($_FILES["p_image"]["tmp_name"],$_SERVER["DOCUMENT_ROOT"]."/hanyu/pic/".$p_image);

        if($statement->error)
        {
                $err=$statement ->error;
                echo"<script>alert('$err');</script>";
        }
        else{
                echo "<script>alert('New Product is successfully inserted!');location.assign('admin_home.php')</script>";
        }
        $statement ->close();
}


?>



<!-- Content Wrapper. Contains page content -->

<div class="content-wrapper">

         <section class="content">
    <div class="row">
        <!-- left column -->
             <div class="col-md-12">
            <!-- Horizontal Form -->
            <div class="box box-info">
                <div class="box-header with-border">
                    <h3 class="text-centre">Product Registration Form</h3>
                </div>
                <!-- /.box-header -->
                <!-- form start -->
                <form class="form-horizontal" method='post' enctype="multipart/form-data">
                    <div class="box-body">
                                                      
                        <div class="form-group">
                            <label style="text-align:left;" for="productName" class="col-sm-3 control-label">Product Name :</label>
                            <div class="col-sm-9">
                                <input type="name" class="form-control" name="prductname" id="inputName" placeholder="Product Name" required>
                            </div>
                        </div>
                                                            
                                                                   <div class="form-group">
                            <label style="text-align:left;"  for="exampleInputType" class="col-sm-3 control-label">Category  :</label>
                                                                        <div class="col-sm-9">
                            <select class="form-control"  name="category_id" required>
                                                <option value="">Select Category</option>
                                                <?php
                                                    $statement = $connection ->prepare("Select * From category");
                                                    $statement ->execute();
                                                    $statement->bind_result($category_id, $category_name);
                                                    while($statement->fetch()) {
                                                        echo "<option value='$category_id'>$category_name</option>";
                                                    }
                                                    $statement->close();
                                                ?>
                                            </select>
											</div>
                                        </div>

                                                                 <div class="form-group">
                            <label style="text-align:left;" for="exampleInputImage" class="col-sm-3 control-label">Product Image :</label>
                                                                        <div class="col-sm-9">
                            <input type="file" name="p_image"id="exampleInputImage" required>
                                                                        </div>
                        </div>

										
										<div class="form-group">
                                            <label style="text-align:left;" for="inputDescription" class="col-sm-3 control-label">Description :</label>
                                            <div class="col-sm-9">
                                                <textarea name="p_describe" id="description" placeholder="Product Description" class="form-control" cols="30" rows="10" required></textarea>
                                            </div>
                                        </div>
										
										
										
										
                                        <div class="form-group">
                                            <label style="text-align:left;" for="inputPrice" class="col-sm-3 control-label">Product Price :</label>
                                            <div class="col-sm-9">
                                                <input type="price" name="p_price" class="form-control" id="inputPrice" placeholder="Product Price" required>
                                            </div>
                                        </div>
										
									
										 <div class="form-group">
                                            <label style="text-align:left;" for="inputQuantity" class="col-sm-3 control-label">Product Quantity:</label>
                                            <div class="col-sm-9">
                                                <input type="quantity" name="p_quantity" class="form-control" id="inputQuantity" placeholder="Product Quantity" required>
                                            </div>
                                        </div>
										
                                        
                                
									</div>
                                    <!-- /.box-body -->
                                     <div class="box-footer">
									 <div class="form-group">
									<div class="col-sm-3"></div>
									 <div class="col-sm-8">
										 <button type="reset" name="btn_cancel" class="btn btn-danger">Cancel</button>
                                        <button type="submit" name="pro_register"  class="btn btn-primary">Submit</button>
										</div>
										</div>
                                    </div>
									
                                    <!-- /.box-footer -->
                                
								</form>
								</div>
								</div>
								</div>
			</section>


               
            </div>


        
        
