<?php require('header2.php');?>
<?php

if(!isset($_SESSION["cus_name"])) {
    echo "<script>alert('Please Login First!.');location.assign('login.php');</script>";
}

if (isset($_POST["confirm"])) 
{
        $c_id=$_SESSION['cus_id'];
        $c_name=$_SESSION['cus_name'];
        $reviewcontent=$_POST["reviewcontent"];
        $statement = $connection ->prepare("Insert Into review(customer_id,review_content) Values(?,?)");

                $statement ->bind_param("is",$c_id,$reviewcontent);
                $statement ->execute();

                if($statement->error)
                {
                        $err=$statement ->error;
                        echo"<script>alert('$err');</script>";
                }
                else{				

                        echo "<script>alert('Your Review has been posted on this page!');location.assign('review.php');</script>";
                }
                $statement ->close(); 
	}
?>	
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper" >
<center><b>Hello <?php echo $_SESSION['cus_name'];$_SESSION['cus_id']?>! This is a review area and please feel free to discuss anything about our page "Hanyu Floral Shop" !</b></center>
<br>
			 <section>
                    <div class="row">
                        <!-- left column -->
                             <div class="col-md-12">
                            <!-- Horizontal Form -->
                            <div class="box box-info">
<div class="box-header with-border">
    <h3 class="text-centre"> Review</h3>
</div>

<!-- /.box-header -->
<!-- form start -->
<form class="form-horizontal" method='post' enctype="multipart/form-data">
    <div class="box-body">
<div style="width:1000px !important;height:300px; border-color:white; border-width:5px; overflow:auto; ">
<div class="row">

        <?php
                $statement=$connection->prepare("(Select r.review_content, r.review_date, c.customer_name From review r, customer c WHERE r.customer_id = c.customer_id) UNION (Select r.review_content, r.review_date, a.admin_name From review r, admin a"
                        . " WHERE r.admin_id= a.admin_id) ORDER BY review_date");
                $statement->execute();
                $statement->bind_result($comment,$r_date,$r_name);
                while($statement->fetch()) {
?>	
<div class="form-group" style="margin-left:1em;">
<label style="text-align:left;" for="inputImage" class="col-sm-3 control-label"> <img src="img/commenticon.png" style="width: 60px; height: 50px;" />  </label>
        <label style="text-align:left;" for="inputImage" class="col-sm-3 control-label"><b>&nbsp;<?php echo $r_name;?></b>: </label>
<div class="col-sm-9">
                &nbsp;&nbsp;<?php echo $comment;?>
</div>
</div>
<?php	
        }
        $statement->close();
?>

</form>
</div>
</div>
</div>
</div>
</section>

<form name="f1" method="POST">
<table cellpadding="10">
<tr>
<td><img src="img/commenticon.png" width="55" height="55"></td> 
<td><textarea name="reviewcontent" rows="5" cols="80" placeholder="Write Something"></textarea></td>
</tr>
<tr>
<td></td>
<td> <button type="reset" name="btn_cancel" class="btn btn-danger">Cancel</button>
<button type="submit" name="confirm"  class="btn btn-primary" onclick="location.assign('review.php')" >Post</button></td>
</tr>			
</table>
</form>

</div>



        
        
