
<?php
require'mysql_connection.php';
session_start();
if(!isset($_SESSION["admin_id"]) ){
      header("location: index.php");
  }
?>      

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <title>Hanyu Floral & Gift</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karma">
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="css/AdminLTE.min.css">

    <link rel="stylesheet" href="css/style.css">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
        <title></title>
        <style>
          *{
  box-sizing: border-box;
}
body{
  height:100%;
  background-color: #444;
}
h1{
  font-size:1em;
  text-align:center;
  color: #eee;
  letter-spacing:1px;
  text-shadow: 1px 1px 1px rgba(0,0,0,0.5);
}
.nav-container{
  width:300px;
  margin-top:50px;
  box-shadow: 0 2px 2px 2px black;
  transition: all 0.3s linear;
}
.nav{
  list-style-type:none;
  margin:0;
  padding:0;
  position:absolute;
}
li{
  height:50px; 
  position:relative;
  background: linear-gradient(#292929, #242424);
}
a {
  border-top: 1px solid rgba(255,255,255,0.1);
  border-bottom: 1px solid black;
  text-decoration:none;
  display:block;
  height:100%;
  width:100%;
  line-height:50px;
  color:#bbb;
  text-transform: uppercase;
  font-weight: bold;
  padding-left:25%;
  border-left:5px solid transparent;
  letter-spacing:1px;
  transition: all 0.3s linear;
}
.active a{
  color: #B93632;
  border-left:5px solid #B93632;
  background-color: #1B1B1B;
  outline:0;
}
li:not(.active):hover a{
  color: #eee;
  border-left: 5px solid #FCFCFC;
  background-color: #1B1B1B;
}
span[class ^= "icon"]{
  position:absolute;
  left:20px;
  font-size: 1.5em;
  transition: all 0.3s linear;
}

@media only screen and (max-width : 860px){
  
  .text{
    display:none;
  }
  
  .nav-container , a{
    width: 70px;
    
  }
   
  a:hover{
    width:200px; 
    z-index:1;
    border-top: 1px solid rgba(255,255,255,0.1);
    border-bottom: 1px solid black;
    box-shadow: 0 0 1px 1px black;
  }
  
  a:hover  .text {
    display:block;
    padding-left:30%;
  }
}
@media only screen and (max-width : 480px){
  .nav-container, a{ width:50px;}
  span[class ^= "icon"]{ left:8px;}
}
  
        </style>
        <script>
            $('li').click(function(){
  
  $(this).addClass('active')
       .siblings()
       .removeClass('active');
    
});
</script>
    </head>
    
    <body style="background-color: whitesmoke">
        <h1>Admin Home</h1><div class="w3-top">
  <div class="w3-bar w3-white w3-padding w3-card" style="letter-spacing:4px;">
    <a href="admin_home.php" class="w3-bar-item w3-button">Hanyu Floral & Gift </a>
    <!-- Right-sided navbar links. Hide them on small screens -->
    <div class="w3-right">
        <a href="cregister.php" class="w3-bar-item w3-button">Register</a>
	<a href="login.php" class="w3-bar-item w3-button">Log In </a>
        <a href="logout.php" class="w3-bar-item w3-button">Log Out </a>
	
    </div>
  </div>
</div>
<div class="nav-container" style="background-color: whitesmoke">
  <ul class="nav">
    <li>
      <a href="admin_home.php">
        <span class="icon-home"></span>
        <span class="text">home</span>
      </a>
    </li>
      <li>
           <a href="adminregister.php">
        <span class="icon-headphones"></span>
        <span class="text">Register Admin</span>
      </a>
      </li>
        <li>
           <a href="adminlist.php">
        <span class="icon-headphones"></span>
        <span class="text">Admin List</span>
      </a>
      </li>
        <li>
            <a href="categorylist.php">
        <span class="icon-picture"></span>
        <span class="text">category List</span>    
      </a>
    </li>
    <li>
        <a href="categoryregister.php">
        <span class="icon-user"></span>
        <span class="text">category register</span>
      </a>
      </li>
        <li>
        <a href="productlist.php">
        <span class="icon-user"></span>
        <span class="text">product list</span>
      </a>
      </li>
    <li>
        <a href="productregister.php">
        <span class="icon-headphones"></span>
        <span class="text">product register</span>
      </a>
      </li>
       <li>
           <a href="vieworderlist.php">
        <span class="icon-headphones"></span>
        <span class="text">Order List</span>
      </a>
      </li>
  <li>
           <a href="viewreview.php">
        <span class="icon-headphones"></span>
        <span class="text">Review Reply</span>
      </a>
      </li>
    <li>
      <a href="viewreport.php">
        <span class="icon-facetime-video"></span><span class="text">View Report</span>
      </a>
    </li>
  </ul>
</div>
    </body>
</html>
