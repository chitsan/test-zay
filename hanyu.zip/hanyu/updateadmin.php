<?php require('sidemenu.php');?>



<?php
if(isset($_POST["update"])){
	
	$admin_email=$_POST["admin_email"];
	$admin_password=$_POST["admin_password"];
	$admin_name=$_POST["admin_name"];
				
	$statement =$connection ->prepare ("Update admin Set email=?, admin_name=?, admin_password=? Where admin_id=?");
					$statement->bind_param("sssi",$admin_email,$admin_name,$admin_password,$_SESSION["updateadmin_id"]);
					
				
				$statement ->execute();
				 if ($statement ->error){
				 	$statement ->close();
				 	echo "<script> alert ('Admin pdate Failed ! Please try again !');</script>";
				 }
				 else
				 {
				 	$statement ->close ();
					
				$admin_email="";
				$admin_password="";
				$admin_name="";
			
				
				
				unset($_SESSION["updateadmin_id"]);
				echo "<script> alert('Staff Information is Updated Successfully !');location.assign('adminlist.php');</script>";
				 }
			}

	if(isset($_GET["uid"])){
		$id=$_GET["uid"];
		$_SESSION["updateadmin_id"] = $id;
		$statement=$connection->prepare("Select admin_id,admin_name,admin_password,email From admin where admin_id=?");
		$statement->bind_param("i",$id);
		$statement->execute();
		$statement->bind_result($admin_id,$admin_name,$admin_password,$admin_email);
		$statement->fetch();
		$statement->close();
		
	}
?>


            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
			
			 <section class="content">
                    <div class="row">
                        <!-- left column -->
                             <div class="col-md-12">
                            <!-- Horizontal Form -->
                            <div class="box box-info">
                                <div class="box-header with-border">
                                    <h3 class="text-centre">Admin Update Form</h3>
                                </div>
                                <!-- /.box-header -->
                                <!-- form start -->
                                <form class="form-horizontal" method='post' enctype="multipart/form-data" >
                                    <div class="box-body">
		                    <div class="col-md-9">
                                        
										
										 <div class="form-group">
                                            <label style="text-align:left;" for="exampleInputPhone" class="col-sm-3 control-label">Admin Name :</label>
											<div class="col-sm-5">
												<input type="text" name="admin_name" class="form-control" id="inputName"  value="<?php echo $admin_name;?>" >
											</div>
                                        </div>
										
										
										
										
										
										
										
										
										<div class="form-group">
                                            <label style="text-align:left;" for="exampleInputPosition" class="col-sm-3 control-label">Admin Email :</label>
											<div class="col-sm-5">
												<input type="email" name="admin_email" class="form-control" id="inputEmail"  value="<?php echo $admin_email;?>" >
											</div>
                                        </div>
										
										
                                        <div class="form-group">
                                            <label style="text-align:left;" for="exampleInputAddress" class="col-sm-3 control-label">Admin Password :</label>
											<div class="col-sm-5">
												<input type="password" name="admin_password" class="form-control" id="inputPassword"  value="<?php echo $admin_password;?>" >
											</div>
                                        </div>
										
                                        
                                    </div>
									</div>
                                    <!-- /.box-body -->
                                     <div class="box-footer">
									 <div class="form-group">
									<div class="col-sm-3"></div>
									 <div class="col-sm-8">
										 <button type="reset" name="btn_cancel" class="btn btn-danger" onclick="location.assign('adminlist.php')" >Cancel</button>
                                        <button type="submit" name="update"  class="btn btn-primary">Update</button>
										</div>
										</div>
                                    </div>
									
                                    <!-- /.box-footer -->
                                
								</form>
								</div>
								</div>
								</div>
			</section>
		


               
            </div>

        
        
