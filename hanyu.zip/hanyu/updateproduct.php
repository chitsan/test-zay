<?php require('sidemenu.php');?>

<?php
if(isset($_POST["updateproduct"])){
	
	$p_price=$_POST["p_price"];
	
	$p_quantity=$_POST["p_quantity"];
	
				
	$statement =$connection ->prepare ("Update product Set product_price=?,product_quantity=?  Where product_id=?");
					$statement->bind_param("iii",$p_price,$p_quantity,$_SESSION["p_id"]);
					
				
				$statement ->execute();
				 if ($statement ->error){
				 	$statement ->close();
				 	echo "<script> alert ('Update Failed ! Please try again !');</script>";
				 }
				 else
				 {
				 	$statement ->close ();
					
				$p_name="";
				$p_image="";
				$_id="";
				$c_describe="";
				$c_price="";
				
				$c_quantity="";
				
				
				unset($_SESSION["p_id"]);
				echo "<script> alert('Item is Updated Successfully !');location.assign('productlist.php');</script>";
				 }
			}

	if(isset($_GET["u_pid"])){
		$p_id=$_GET["u_pid"];
		$_SESSION["p_id"] = $p_id;
		$statement=$connection->prepare("Select * From product p, category c 
										where product_id=?
										and c.category_id= c.category_id");
		$statement->bind_param("i",$p_id);
		$statement->execute();
		$statement->bind_result($p_id,$p_name,$p_price,$p_describe,$p_image,$category_id,$p_quantity,$category_id,$category_name);
		$statement->fetch();
		$statement->close();
		
	}
?>



            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
			
			 <section class="content">
                    <div class="row">
                      
                            <!-- Horizontal Form -->
                            <div class="box box-info">
                                <div class="box-header with-border">
                                    <h3 class="text-centre">Product Update Form</h3>
                                </div>
                                <!-- /.box-header -->
                                <!-- form start -->
                                <form class="form-horizontal" method='post' enctype="multipart/form-data">
                                    <div class="box-body">
									
                                        <div class="form-group">
                                            <label style="text-align:left;" for="inputName" class="col-sm-3 control-label">Product Name :</label>
                                            <div class="col-sm-9">
                                                <?php echo $p_name;?>
                                            </div>
                                        </div>
										
										 <div class="form-group">
                                            <label style="text-align:left;" for="image" class="col-sm-3 control-label">Product Image :</label>
											<div class="col-sm-9">
                                            <img src="pic/<?php echo $p_image;?>" style="width: 200px; height: 150px;"/>
											</div>
                                        </div>
										
										   <div class="form-group">
                                            <label style="text-align:left;"  for="categoryname" class="col-sm-3 control-label">Category  :</label>
											<div class="col-sm-9">
												<?php echo $category_name;?>
											</div>
                                        </div>
										
										
										
										
										<div class="form-group">
                                            <label style="text-align:left;" for="inputDescription" class="col-sm-3 control-label">Description :</label>
                                            <div class="col-sm-9">
												<?php echo $p_describe;?>
                                            </div>
                                        </div>
										
                                        <div class="form-group">
                                            <label style="text-align:left;" for="inputPrice" class="col-sm-3 control-label">Item Price :</label>
                                            <div class="col-sm-9">
                                                <input type="price" name="p_price" class="form-control" id="inputPrice" placeholder="Product Price" value="<?php echo $p_price;?>" >
                                            </div>
                                        </div>
									
										 <div class="form-group">
                                            <label style="text-align:left;" for="inputQuantity" class="col-sm-3 control-label">Product Quantity:</label>
                                            <div class="col-sm-9">
                                                <input type="quantity" name="p_quantity" class="form-control" id="inputQuantity" placeholder="Product Quantity" value="<?php echo $p_quantity;?>" >
                                            </div>
                                        </div>
										
                                        
                                   
									</div>
                                    <!-- /.box-body -->
                                     <div class="box-footer">
									 <div class="form-group">
									<div class="col-sm-3"></div>
									 <div class="col-sm-8">
										 <button type="reset" name="btn_cancel" class="btn btn-danger" onclick="location.assign('item_list.php')" >Cancel</button>
                                        <button type="submit" name="updateproduct"  class="btn btn-primary">Update</button>
										</div>
										</div>
                                    </div>
									
                                    <!-- /.box-footer -->
                                
								</form>
								</div>
								</div>
								</div>
			</section>
		


               
            


        
        
