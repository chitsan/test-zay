
<?php require('sidemenu.php');?>


<?php

 
  if(isset($_GET["oid"])){
		$id=$_GET["oid"];
		$statement=$connection->prepare("Delete From ordertable where o_id=?");
		$statement->bind_param("i",$id);
		$statement->execute();
		if($statement->error){
		$statement->close();
			echo"<script>alert('Something Wrong!');</script>";
		}
		else{
		$statement->close();
		$files=glob($_SERVER["DOCUMENT_ROOT"]."/aurora_by_syl/pic/".$id. ".*");
		foreach ($files as $f){
			unlink($f);
		}
		echo"<script>alert('Your order is deleted successfully !');location.assign('order_list.php');</script>";
		}
	}
 ?>


            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
			
			<div class="row">
            <div class="container">
                <div class="table-responsive" style=" overflow:auto;">
                    <form name="frm2" action="" method="post" enctype="multipart/form-data">
                                        <table class="table" style="border:2px solid black; width:98%;">
                        <thead style="background-color: skyblue; color:black;">
                           
                            <tr style="font-size: 1em;">
                                  
                                                                <th>Customer Name</th>
                                                                <th>Order Confirm</th>   
								<th>Delivery Confirm</th> 
								<th>Order Date</th> 
                                                                <th>Delivery Date</th>
								<th>Total Amount</th>  
								<th colspan="2" class="text-center">Action</th>  
                            </tr>
                        </thead>
                        <tbody>
			<?php	
				
                            
                                          $result=$connection->query("select distinct o.order_id,c.customer_name,o.confirm_order,o.confirm_delivery,o.order_date,d.delivery_date,o.order_total from
                                    customer c,porder o,delivery d
                                    where c.customer_id=o.customer_id
                               
                                    and d.delivery_id=o.delivery_id");

	while($row=$result->fetch_assoc()){
		$o_id = $row["order_id"];
	

?>
			<tr>	
				
				<td><?php echo $row["customer_name"];?></td>
                             
                                <td><?php echo $row["confirm_order"] ;?></td>
                           
                            <td><?php echo  $row["confirm_delivery"] ;?></td>
                               
                               
                               <td><?php echo $row["order_date"];?></td>
				<td><?php echo $row["delivery_date"];?></td>
				<td><?php echo $row["order_total"];?></td>
				
	
	
	<td><input type="Button" style="background-color:green; color:white;" 
                   value="Action" onclick="location.assign('orderdetail.php?o_id=<?php echo $o_id;?>')"/></td>
	

</tr>
<?php } $result->free(); ?>




                        </tbody>
                    </table>
                    </form>
                </div>
                
                
               
            </div>
        </div>
		


               
            </div>



        
        
