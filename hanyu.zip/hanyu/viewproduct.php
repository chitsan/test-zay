
<?php 

  require'header2.php';
?>
<?php
 include_once("product.php");
if(isset($_POST["addCart"])){
    
     if(isset($_SESSION['pid'])){
       
                        $pid=$_SESSION['pid'];
    if($_POST["quantity"]==0){
        echo"<script> alert ('Please choose the quantity ');location.assign('viewproduct.php?pid=$pid');  </script>";
    }else{
echo"<script> alert ('adding Card');  </script>";
if(!isset($_SESSION['cart_items'])){
    $_SESSION['cart_items'] = array();
}
                        $s=$connection->prepare("Select * From product p Where  p.product_id='$pid'");

$s->execute();
$s->bind_result($product_id,$product_name,$product_price,$porduct_desc,$product_image,$category_id,$product_quantity);
      
$s->fetch();
$s->close();
                      
                           $product = new product( $product_id,$product_name,$product_price,$product_image,$_POST["quantity"]);
                       

array_push($_SESSION['cart_items'], $product);
echo"<script> location.assign('cart.php');</script>"; 
     }

}
}
?>
 <div class="container" style="height:1000px">
     
<form method="POST">
<?php
                if(isset($_GET["pid"])){
            
                        $pid=$_GET["pid"];
                                $_SESSION['pid']=$pid;
                        $result=$connection->query("Select * From product p Where  p.product_id='$pid'");
                       }
                      

              while($row=$result->fetch_assoc()){
               $p_id = $row["product_id"];	

        ?>
        <div class="row">
            <div class="col-md-6">
			<div class="row">
                   
                       <img src="pic/<?php echo $row['product_image']; ?>" style="width:500px; height:425px; margin-top:100px;"/>
                   
                </div>
			</div>
			<div class="col-md-6">
		
               <div class="login-box" style="margin-top:10em;">

            <!-- /.login-logo -->
            <div class="panel-body">

                <header style="font-size:24px"><b><?php echo $row["product_name"]; ?></b></header>

<br>
<b> Price:</b><?php echo $row["product_price"]; ?> $USD<br>
<b> Description:</b><p><?php echo $row["product_description"]; ?></p><br>
<b> Quantity:</b><p><input type="number" name="quantity" value="1"/></p><br>
                <input type="submit" value="Add To cart" name="addCart" class="btn btn-success"><br>

            </div>
            </div>
			</div>
			
			
			
			
            </div>
			
      
			
	
<?php
}
$result->free();
?>
</form>

               
            </div>


         <hr>

          <div class="w3-container w3-light-blue-grey w3-padding-20" id="contact">
    <h1>Contact</h1><br>
    <p>We offer service for event, wedding or special moment. We understand your needs and we will arrange your needs
        to memorize the biggest moment of life. Do not hesitate to contact us.</p>
    <p class="w3-text-blue-grey w3-large"><b>Hanyu Floral & Gift,Yadanapone Street,Kyeemyintdaine Township,Yangon</b></p>
    <p>You can also contact us by phone +959450017312 or email hanyu@floral.com</p>
    
  </div>
  
<!-- End page content -->
</div>

<!-- Footer -->
<footer class="w3-center w3-light-grey w3-padding-32">
     <p>Created by Chit Chit San</p>
  <p>Powered by <a href="https://www.w3schools.com/w3css/default.asp" title="W3.CSS" target="_blank" class="w3-hover-text-green">w3.css</a></p>
</footer>
          
        
