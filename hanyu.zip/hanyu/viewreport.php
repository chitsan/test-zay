<?php require('sidemenu.php');?>

            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
			
			<div>
										<button type="button" style="margin-top:200px; margin-left:100px; font-size:1.5em;" name="btn_sales" class="btn btn-danger" onclick="location.assign('dailyorder.php')">Daily Order Report Page</button>
										
										<button type="button" style="margin-top:200px; margin-left:100px; font-size:1.5em;" name="btn_bestSeller" class="btn btn-danger" onclick="location.assign('popularitem.php')">Popular Products</button>
					
<button type="button" style="margin-top:200px; margin-left:100px; font-size:1.5em;" name="btn_inStock" class="btn btn-danger" onclick="location.assign('dailydelivery.php')">Daily Order Delivery Report</button>
		
			</div>

               
            </div>


