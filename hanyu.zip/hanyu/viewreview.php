
<?php require('sidemenu.php');?>



<?php



	if(!isset($_SESSION["admin_name"])) {
            echo "<script>alert('Please Login First!.');location.assign('login.php');</script>";
        }
		
	if (isset($_POST["confirm"])) 
	{
            
		
		$a_id=$_SESSION['admin_id'];
		$a_name=$_SESSION['admin_name'];
		$comment=$_POST["replycomment"];
              
		$statement = $connection ->prepare("Insert Into review(admin_id,review_content) Values(?,?)");
		
			$statement ->bind_param("is",$a_id,$comment);
			$statement ->execute();
		
			if($statement->error)
			{
				$err=$statement ->error;
				echo"<script>alert('$err');</script>";
			}
			else{				
					
				echo "<script>alert('Your comment has been posted on this page!');location.assign('viewreview.php');</script>";
			}
			$statement ->close(); 
	}
	
	
	 if(isset($_GET["did"])){
		$id=$_GET["did"];
		$statement=$connection->prepare("Delete From review where review_id=?");
		$statement->bind_param("i",$id);
		$statement->execute();
		if($statement->error){
		$statement->close();
			echo"<script>alert('Something Wrong!');</script>";
		}
		else{
		$statement->close();
		
		echo"<script>alert('Your feedback is deleted successfully !');location.assign('viewreview.php');</script>";
		}
	}
	
	
?>	





            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
			
			<center><b>Hello <?php echo $_SESSION['admin_name'];$_SESSION['admin_id']?>! 
                             Give reply to review of your "Hanyu Floral Shop" !</b></center>
<br>
                        <!-- left column -->
                             <div class="col-md-9">
                            <!-- Horizontal Form -->
                            <div class="box box-info">
                                <div class="box-header with-border">
                                    <h3 class="text-centre"> Review Feedback</h3>
                                </div>
								
                                <!-- /.box-header -->
                                <!-- form start -->
                                <form class="form-horizontal" method='post' enctype="multipart/form-data">
                                    <div class="box-body" >
<div style="width:1000px !important;height:300px; border-color:white; border-width:5px; overflow:auto; ">
<div class="row" >

<?php
$statement=$connection->prepare("(Select r.review_id, r.review_content, r.review_date, c.customer_name From review r, 
        customer c WHERE r.customer_id = c.customer_id) 
        UNION (Select r.review_id,r.review_content, r.review_date, a.admin_name From review r, admin a
             WHERE r.admin_id= a.admin_id) ORDER BY review_date");
$statement->execute();

$statement->bind_result($r_id,$comment,$r_date,$r_name);
while($statement->fetch()) {
										?>	
<div class="form-group" style="margin-left:1em;">
<label style="text-align:left;" for="inputImage" class="col-sm-3 control-label"> <img src="img/commenticon.png" style="width: 60px; height: 50px;" />  </label>
        <label style="text-align:left;" for="inputImage" class="col-sm-3 control-label"><b>&nbsp;<?php echo $r_name;?></b>: </label>
<div class="col-sm-9">
                &nbsp;&nbsp;<?php echo $comment;?>
</div>
        <button type="button" name="btn_cancel" class="btn btn-danger" onclick="location.assign('viewreview.php?did=<?php echo $r_id; ?>')">Delete</button>

</div>
<?php	
        }
        $statement->close();
?>
										
						</form>
						</div>
						</div>
						</div>
						</div>
			</section>

			
      		<form name="f1" method="POST">
			<table cellpadding="10">
			<tr>
				<td><img src="img/commenticon.png" width="60" height="50"></td> 
				<td><textarea name="replycomment" rows="5" cols="80" placeholder="Reply Something"></textarea></td>
			</tr>
			<tr>
				<td></td>
				<td> <button type="reset" name="btn_cancel" class="btn btn-danger">Cancel</button>
				<button type="submit" name="confirm"  class="btn btn-primary" onclick="location.assign('viewfeedback.php')" >Post</button></td>
			</tr>			
			</table>
			</form>


               
            </div>


        
        
